"use client";

import React, { useState } from "react";
import { Button, Input } from "@heroui/react";
import axios from "axios";
import { useForm } from "react-hook-form";
import { removeProfile } from "@/actions/authActions";
import { toast } from "react-toastify";
import { updateUserById } from "@/actions/authActions";

const Profile = ({ user }) => {
  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors, isSubmitting },
  } = useForm({
    mode: "onTouched",
    defaultValues: {
      profileImage: user?.profileImage || {},
      firstname: user?.firstname || "",
      lastname: user?.lastname || "",
      email: user?.email || "",
      storename: user?.storename || "",
    },
  });

  const [loading, setLoading] = useState(false);
  const [previewUrl, setPreviewUrl] = useState(user?.profileImage?.url || "");

  const handleImageChange = async (e) => {
    const file = e.target.files[0];
    setLoading(true);
    if (file) {
      const formData = new FormData();
      formData.append("file", file);

      const response = await axios.post("/api/upload", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      const { publicId, url } = response.data;
      setValue("profileImage", { publicId: publicId, url: url });
      setLoading(false);
      const reader = new FileReader();
      reader.onloadend = () => setPreviewUrl(reader.result);
      reader.readAsDataURL(file);
    }
  };

  const onSubmit = async (data) => {
    try {
      const response = await updateUserById(user._id, data);
      if (response.status === 200) {
        toast.success("User updated successfully!", {
          position: "top-right",
          autoClose: 2000,
        });
      }
    } catch (error) {
      console.error("Error updating user:", error);
    }
  };

  const handleRemoveImage = async () => {
    // Remove the profile image by resetting it in the form and state
    const response = await removeProfile(user._id);
    if (response.status == 200) {
      setValue("profileImage", {});
      setPreviewUrl("");
      toast.success("Image deleted successfully!", {
        position: "top-right",
        autoClose: 2000,
      });
    }
  };

  return (
    <>Profile Page</>
    // <form className="w-full mb-8" onSubmit={handleSubmit(onSubmit)}>
    //   <div className="mb-8">
    //     <label className="block text-lg">Profile Picture</label>
    //     <input
    //       type="file"
    //       accept="image/*"
    //       onChange={handleImageChange}
    //       className="mt-2"
    //     />
    //     {previewUrl  ? (
    //       <div className="mt-4">
    //         <img
    //           src={previewUrl}
    //           alt="Profile Image"
    //           style={{ width: 100, height: 100, borderRadius: "50%" }}
    //         />
    //         <button
    //           type="button"
    //           onClick={handleRemoveImage}
    //           className="mt-2 text-red-600"
    //         >
    //           Remove Profile Picture
    //         </button>
    //       </div>
    //     ) : null}
    //     {loading && <p>Loading...</p>}
    //   </div>
    //   <div className="mb-8">
    //     <Input
    //       defaultValue=""
    //       label="First Name"
    //       size="lg"
    //       {...register("firstname", {
    //         required: "First Name is required",
    //       })}
    //     />
    //     {errors.firstname && (
    //       <span style={{ color: "red", fontSize: "12px" }}>
    //         {errors.firstname.message}
    //       </span>
    //     )}
    //   </div>
    //   <div className="mb-8">
    //     <Input
    //       defaultValue=""
    //       label="Last Name"
    //       size="lg"
    //       {...register("lastname", {
    //         required: "Last Name is required",
    //       })}
    //     />
    //     {errors.lastname && (
    //       <span style={{ color: "red", fontSize: "12px" }}>
    //         {errors.lastname.message}
    //       </span>
    //     )}
    //   </div>
    //   <div className="mb-8">
    //     <Input
    //       label="Store Name"
    //       size="lg"
    //       disabled
    //       {...register("storename", {
    //         required: "Store Name is required",
    //       })}
    //     />
    //   </div>
    //   <div className="mb-8">
    //     <Input
    //       label="Email"
    //       type="email"
    //       size="lg"
    //       disabled
    //       defaultValue="user@example.com"
    //     />
    //   </div>
    //   <div className="mb-4 bg">
    //     <Button
    //       isLoading={isSubmitting}
    //       type="submit"
    //       className="text-[1.2rem] px-6 py-6 text-white rounded-[8px]"
    //       color="success"
    //     >
    //       Save
    //     </Button>
    //   </div>
    // </form>
  );
};

export default Profile;
